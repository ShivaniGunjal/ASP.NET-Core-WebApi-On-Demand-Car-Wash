using System.ComponentModel.DataAnnotations;


namespace CarWashApi.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }
        
        [Required]
        public required string FirstName { get; set; }
        
        [Required]
        public required string LastName { get; set; }
        
        [Required]
        public required string Email { get; set; }
        
        [Required]
        public string Password { get; set; }
        
        public long PhoneNumber { get; set; }
        
        [Required]
        public  string Address { get; set; }
        
        public bool IsWasher { get; set; }
        
        public bool IsActive { get; set; }
        // Navigation properties
        public  ICollection<Car> Cars { get; set; }  // One User can own many Cars
        public  ICollection<Order> Orders { get; set; }  // One User can have many Orders
        public  ICollection<Review> Reviews { get; set; }  // One User can write many Reviews
       
    }
}
