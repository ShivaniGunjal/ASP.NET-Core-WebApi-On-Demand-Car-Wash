using System;
using System.ComponentModel.DataAnnotations;

namespace CarWashApi.Validators
{
    public class CustomCompletedDateValidation : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value is DateTime dateTime)
            {
                // Check if the date is today or a future date (ignoring time)
                return dateTime.Date >= DateTime.UtcNow.Date;
            }
            return false;
        }
    }
}
