

// using System.Net;
// using System.Net.Mail;
// using System.Threading.Tasks;
// using CarWashApi.Models;

// namespace CarWashApi.Services
// {
//     public interface IEmailService
//     {
//         Task SendLoginEmail(User user);  // Only keep this method for sending login emails
         
//     }

//     public class EmailService : IEmailService
//     {
//         private readonly string _smtpServer = "smtp.gmail.com";
//         private readonly int _smtpPort = 587; // For TLS
//         private readonly string _smtpUsername = "shivanigunjal1902@gmail.com"; // Replace with your email
//         private readonly string _smtpPassword = "ggkf dqba erie omjt"; // Replace with your email password
        
//         // This method sends an email when a user logs in
//         public async Task SendLoginEmail(User user)
//         {
//             if (user == null)
//             {
//                 return;
//             }

//             var subject = "Welcome to Green Wash!";
//             var body = $@"
//             <h1>Welcome, {user.FirstName}!</h1>
//             <p>Thank you for Logging with Green Wash.</p>
//             <p>Your User ID: {user.UserId}</p>
//             <p>We are excited to help you with your car wash needs.</p>
//             <p>Thank you for choosing us!</p>";

//             using (var smtpClient = new SmtpClient(_smtpServer, _smtpPort))
//             {
//                 smtpClient.Credentials = new NetworkCredential(_smtpUsername, _smtpPassword);
//                 smtpClient.EnableSsl = true;

//                 var mailMessage = new MailMessage
//                 {
//                     From = new MailAddress(_smtpUsername),
//                     Subject = subject,
//                     Body = body,
//                     IsBodyHtml = true
//                 };
//                 mailMessage.To.Add(user.Email);

//                 await smtpClient.SendMailAsync(mailMessage);
//             }
//         }
//     }
// }

using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using CarWashApi.Models;

namespace CarWashApi.Services
{
    public interface IEmailService
    {
        Task SendEmail(User user, bool isLoginEmail);  // New method that handles both login and registration emails
    }

    public class EmailService : IEmailService
    {
        private readonly string _smtpServer = "smtp.gmail.com";
        private readonly int _smtpPort = 587; // For TLS
        private readonly string _smtpUsername = "shivanigunjal1902@gmail.com"; // Replace with your email
        private readonly string _smtpPassword = "ggkf dqba erie omjt"; // Replace with your email password

        // This method sends an email when a user logs in or registers
        public async Task SendEmail(User user, bool isLoginEmail)
        {
            if (user == null)
            {
                return;
            }

            // Set email subject and body based on the type of email (login or registration)
            string subject = "";
            string body = "";

            if (isLoginEmail)
            {
                subject = "Welcome Back to Green Wash!";
                body = $@"
                    <h1>Welcome back, {user.FirstName}!</h1>
                    <p>Thank you for logging in to Green Wash.</p>
                    <p>Your User ID: {user.UserId}</p>
                    <p>We are excited to continue helping you with your car wash needs.</p>
                    <p>Thank you for choosing us!</p>";
            }
            else
            {
                subject = "Welcome to Green Wash!";
                body = $@"
                    <h1>Welcome, {user.FirstName}!</h1>
                    <p>Thank you for registering with Green Wash.</p>
                    <p>Your User ID: {user.UserId}</p>
                    <p>We are excited to help you with your car wash needs.</p>
                    <p>Feel free to log in and book your first wash!</p>
                    <p>Thank you for choosing us!</p>";
            }

            using (var smtpClient = new SmtpClient(_smtpServer, _smtpPort))
            {
                smtpClient.Credentials = new NetworkCredential(_smtpUsername, _smtpPassword);
                smtpClient.EnableSsl = true;

                var mailMessage = new MailMessage
                {
                    From = new MailAddress(_smtpUsername),
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true
                };
                mailMessage.To.Add(user.Email);

                await smtpClient.SendMailAsync(mailMessage);
            }
        }
    }
}
