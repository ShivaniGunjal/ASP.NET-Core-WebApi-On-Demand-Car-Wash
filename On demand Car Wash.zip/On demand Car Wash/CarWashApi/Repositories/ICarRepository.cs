using CarWashApi.DTOs;
using CarWashApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CarWashApi.Repositories
{
    public interface ICarRepository
    {
        Task<Car> AddCarAsync(CarDTO carDTO);
        Task<IEnumerable<Car>> GetAllCarsAsync();
        Task<Car> GetCarByMakeAsync(string make);
        Task<Car> GetCarByIdAsync(int carId);
        Task<bool> UpdateCarAsync(int carId, CarDTO carDTO);
        Task<bool> DeleteCarAsync(int carId);
    }
}
