using CarWashApi.Models;

namespace CarWashApi.Repositories
{
    public interface IReviewRepository
    {
        Task<Review> CreateReviewAsync(Review review);
        Task<Review> GetReviewByIdAsync(int reviewId);
        Task<List<Review>> GetAllReviewsAsync();
        Task<Review> GetByIdAsync(int id);  // Fetch review by Id
        Task CreateAsync(Review review);    // Create a new review
        Task<IEnumerable<Review>> GetAllAsync();  // Optional: Get all reviews

        
        // Add missing method signatures:
        Task<List<Review>> GetReviewsByUserIdAsync(int userId);  // Get reviews by User ID
        Task<List<Review>> GetReviewsByWasherIdAsync(int washerId);  // Get reviews by Washer ID
        Task<Review> UpdateReviewAsync(Review review);  // Update an existing review
        Task<bool> DeleteReviewAsync(int reviewId);  // Delete a review by ID
    
    }
}
