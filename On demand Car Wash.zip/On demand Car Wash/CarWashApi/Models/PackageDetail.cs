using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace CarWashApi.Models
{
    public class PackageDetail
    {
        [Key]
        public int PackageId { get; set; }
        
        [Required]
        public  string PackageName { get; set; }
        
        public decimal Price { get; set; }
        
        public bool IsActive { get; set; }

        // Navigation property
        public  ICollection<Order> Orders { get; set; }  // One PackageDetail can be associated with many Orders
    }
}
