using CarWashApi.DTOs;
using CarWashApi.Models;
using System.Threading.Tasks;

namespace CarWashApi.Repositories
{
    public interface IWasherRepository
    {
        Task<WasherDTO> GetWasherByIdAsync(int id);
          Task<User> GetByIdAsync(int washerId);
          
        
    }
}
