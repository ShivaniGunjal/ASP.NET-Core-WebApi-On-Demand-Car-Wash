// AdminController.cs
using CarWashApi.DTOs;
using CarWashApi.Models;
using CarWashApi.Repositories;
using CarWashApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace CarWashApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly IWasherRepository _washerRepository;
        private readonly IOrderRepository _orderRepository;
        private readonly IConfiguration _configuration;
        private readonly IReportRepository _reportRepository;
        private readonly IUserRepository _userRepository;
        private readonly IPaymentRepository _paymentRepository;
        private readonly IReviewRepository _reviewRepository;
        // private readonly EmailService _emailService;
        private readonly ILogger<AdminController> _logger;

        // Injecting IUserRepository through constructor
        public AdminController(ApplicationDbContext context, IConfiguration configuration, IUserRepository userRepository, ILogger<AdminController> logger, IOrderRepository orderRepository, IPaymentRepository paymentRepository, IReviewRepository reviewRepository)
        {
            _context = context;
            _configuration = configuration;
            _userRepository = userRepository;
            _orderRepository = orderRepository;
            _paymentRepository = paymentRepository;
            _reviewRepository = reviewRepository;
            //_emailService = emailService;

        }

        // Admin Registration Endpoint
        [HttpPost("register")]


        public async Task<IActionResult> Register([FromBody] Admin adminDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var existingAdmin = await _context.Admins
                                              .FirstOrDefaultAsync(a => a.Email == adminDTO.Email);
            if (existingAdmin != null)
            {
                return BadRequest("Email is already registered.");
            }

            var hashedPassword = BCrypt.Net.BCrypt.HashPassword(adminDTO.Password);
            var admin = new Admin
            {
                Email = adminDTO.Email,
                Password = hashedPassword,
                Role = adminDTO.Role,
            };

            _context.Admins.Add(admin);
            await _context.SaveChangesAsync();

            return Ok("Admin registered successfully.");
        }

        // Admin Login Endpoint
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] AdminLoginDTO loginDTO)
        {
            if (!ModelState.IsValid)  // Check for validation errors
            {
                return BadRequest(ModelState);  // Return all validation errors to the client
            }
            var admin = await _context.Admins
                                       .FirstOrDefaultAsync(a => a.Email == loginDTO.Email);

            if (admin == null || !BCrypt.Net.BCrypt.Verify(loginDTO.Password, admin.Password))
            {
                return Unauthorized("Invalid email or password.");
            }

            var token = GenerateJwtToken(admin.Email);
            return Ok(new { Token = token });
        }

        // Create a new user (customer or washer)
        [HttpPost("create-washer")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> CreateUser([FromBody] UserDTO userDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (userDTO == null)
            {
                return BadRequest("User data is required.");
            }

            var createdUser = await _userRepository.RegisterUserAsync(userDTO);
            if (createdUser == null)
            {
                return BadRequest("User could not be created.");
            }

            return CreatedAtAction(nameof(GetUserByName), new { Name = createdUser.FirstName }, createdUser);
        }

        // Get user by ID (for Admin to view a profile)
        [HttpGet("users/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetUserProfile(int id)
        {
            var user = await _userRepository.GetUserByIdAsync(id);
            if (user == null)
            {
                return NotFound("User not found.");
            }

            return Ok(user);
        }

        // Get user by name
        [HttpGet("get-user/{name}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetUserByName(string name)
        {
            var user = await _userRepository.GetUserByNameAsync(name);
            if (user == null)
            {
                return NotFound("User not found.");
            }
            return Ok(user);
        }

        [HttpGet("orders")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllOrders()
        {
            var orders = await _orderRepository.GetAllOrdersAsync();
            if (orders == null || !orders.Any())
            {
                return NotFound("No orders found.");
            }

            var orderDtos = orders.Select(order => new OrderDTO
            {
                OrderId = order.OrderId,
                OrderDate = order.OrderDate,
                CarId = order.CarId,
            }).ToList();

            return Ok(orderDtos);
        }


        [HttpPut("assign-washer/{orderId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AssignWasher(int orderId, [FromBody] int washerId)
        {

            var order = await _orderRepository.GetOrderByIdAsync(orderId);
            if (order == null)
            {
                return NotFound("Order not found.");
            }

            // Fetch the user by the washerId to verify if it's a valid washer
            var user = await _userRepository.GetUserByIdAsync(washerId); // Assuming _userRepository is used to fetch users
            if (user == null)
            {
                return NotFound("Washer not found.");
            }


            if (!user.IsWasher)
            {
                return BadRequest("This person is a customer, not a washer.");
            }


            order.UserId = washerId;
            await _orderRepository.UpdateOrderAsync(order);

            return Ok("Washer assigned successfully.");
        }


        [HttpDelete("delete-order/{orderId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteOrder(int orderId)
        {
            var result = await _orderRepository.DeleteOrderAsync(orderId);
            if (!result)
            {
                return NotFound("Order not found.");
            }

            return Ok("Order deleted successfully.");
        }

        [HttpGet("all-payments")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllPayments()
        {

            try
            {
                var payments = await _paymentRepository.GetAllPaymentsAsync();
                if (payments == null || !payments.Any())
                {
                    return NotFound("No payments found.");
                }
                return Ok(payments);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpPost("respond-to-review/{reviewId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> RespondToReview(int reviewId, [FromBody] string response)
        {
            if (!ModelState.IsValid)  // Check for validation errors
            {
                return BadRequest(ModelState);  // Return all validation errors to the client
            }
            var review = await _reviewRepository.GetReviewByIdAsync(reviewId);
            if (review == null)
                return NotFound("Review not found.");

            // For now, we assume the response is added to the review (e.g., update the comment field or add a new property)
            review.Comments += $"\n\nAdmin Response: {response}";

            var updatedReview = await _reviewRepository.UpdateReviewAsync(review);

            // Manually serialize the updatedReview with reference handling
            var jsonResponse = JsonSerializer.Serialize(updatedReview, new JsonSerializerOptions
            {
                ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.Preserve,
                WriteIndented = true
            });

            return Ok(jsonResponse); // Return the serialized response
        }

        // 3. Delete a review
        [HttpDelete("delete-review/{reviewId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteReview(int reviewId)
        {

            var isDeleted = await _reviewRepository.DeleteReviewAsync(reviewId);
            if (!isDeleted)
                return NotFound("Review not found.");
            return Ok("Review deleted successfully.");
        }

        // // Admin verifies and sends the email
        // [HttpPut("send-order-completion-email/{orderId}")]
        // [Authorize(Roles = "Admin")]
        // public async Task<IActionResult> SendCompletionEmail(int orderId)
        // {
        //     var order = await _orderRepository.GetOrderByIdAsync(orderId);
        //     if (order == null)
        //     {
        //         return NotFound("Order not found.");
        //     }

        //     // Ensure the order is marked as 'Completed'
        //     if (order.Status != "Completed")
        //     {
        //         return BadRequest("Order is not yet completed.");
        //     }

        // Send the email to the user
        // await _emailService.SendOrderCompletionEmail(order);

        //     return Ok("Order completion email sent to user.");
        // }




        // Generate JWT Token
        private string GenerateJwtToken(string email)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.Name, email),
                new Claim(JwtRegisteredClaimNames.Sub, email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.Role, "Admin")

            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Secret"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddHours(1),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
