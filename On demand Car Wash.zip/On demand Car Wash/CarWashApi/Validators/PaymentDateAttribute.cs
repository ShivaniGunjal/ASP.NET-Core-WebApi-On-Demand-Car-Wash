using System;
using System.ComponentModel.DataAnnotations;

namespace CarWashApi.Validatiors
{
    public class PaymentDateAttribute : ValidationAttribute
    {
        public PaymentDateAttribute() 
            : base("The payment date must be the current date.")
        { }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            // Check if the payment date is today
            if (value is DateTime paymentDate)
            {
                if (paymentDate.Date != DateTime.UtcNow.Date)
                {
                    return new ValidationResult(ErrorMessage ?? "The payment date must be the current date.");
                }
            }

            return ValidationResult.Success;
        }
    }
}
