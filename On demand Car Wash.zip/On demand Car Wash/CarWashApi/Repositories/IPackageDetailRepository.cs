using System.Collections.Generic;
using System.Threading.Tasks;
using CarWashApi.Models;
using CarWashApi.DTOs;

namespace CarWashApi.Repositories
{
    public interface IPackageDetailRepository
    {
        Task<IEnumerable<PackageDetail>> GetAllPackagesAsync(); // Get all packages
        Task<PackageDetail> GetPackageByNameAsync(string packageName); // Get a package by name
        Task<PackageDetail> GetPackageByIdAsync(int packageId); // Get a package by ID
        Task<PackageDetail> AddPackageAsync(PackageDetailDTO packageDTO); // Create a new package
        Task<PackageDetail> UpdatePackageAsync(int packageId, PackageDetailDTO packageDTO); // Update a package
        Task<bool> DeletePackageAsync(int packageId); // Delete a package
    }
}
