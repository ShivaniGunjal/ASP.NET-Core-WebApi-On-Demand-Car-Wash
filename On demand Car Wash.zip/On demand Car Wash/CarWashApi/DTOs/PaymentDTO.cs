using System;
using CarWashApi.Validatiors;

using System.ComponentModel.DataAnnotations;

namespace CarWashApi.DTOs
{
    public class PaymentDTO
    {
        [Required(ErrorMessage = "OrderId is required.")]
        public int OrderId { get; set; }

        [Required(ErrorMessage = "Amount is required.")]
        [Range(0.01, 10000.00, ErrorMessage = "Amount must be between 0.01 and 10,000.")]
        public decimal Amount { get; set; }

        [Required(ErrorMessage = "PaymentMethod is required.")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "PaymentMethod should be between 3 and 50 characters.")]
        public string PaymentMethod { get; set; }

        [PaymentDate]  // Apply the custom validation here
        public DateTime PaymentDate { get; set; }
    }
}
