using System.ComponentModel.DataAnnotations;

namespace CarWashApi.DTOs
{
    public class OrderStatusDTO
    {
        [Required(ErrorMessage = "Status is required.")]
        [StringLength(50, ErrorMessage = "Status cannot be longer than 50 characters.")]
        public string Status { get; set; }
    }
}
