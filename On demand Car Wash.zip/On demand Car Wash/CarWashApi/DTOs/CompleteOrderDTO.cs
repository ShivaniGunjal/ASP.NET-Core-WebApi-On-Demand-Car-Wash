using System;
using CarWashApi.Validatiors;

using System.ComponentModel.DataAnnotations;

namespace CarWashApi.DTOs
{
    public class CompleteOrderDTO
    {
        [Required(ErrorMessage = "Status is required.")]
        [StringLength(50, ErrorMessage = "Status cannot be longer than 50 characters.")]
        public string Status { get; set; }

        [Required(ErrorMessage = "CompletedDate is required.")]
        [CustomCompletedDateValidation(ErrorMessage = "CompletedDate must be either the current date or a future date.")]
        public DateTime? CompletedDate { get; set; }
    }
}
