using CarWashApi.Models;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace CarWashApi.Repositories
{
    public class AdminRepository : IAdminRepository
    {
        private readonly ApplicationDbContext _context;

        public AdminRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Admin> GetAdminByEmailAsync(string email)
        {
            return await _context.Admins.SingleOrDefaultAsync(admin => admin.Email == email);
        }

        public async Task AddAdminAsync(Admin admin)
        {
            await _context.Admins.AddAsync(admin);
            await _context.SaveChangesAsync();
        }
    }
}
