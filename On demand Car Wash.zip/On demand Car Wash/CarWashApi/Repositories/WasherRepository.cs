using CarWashApi.DTOs;
using CarWashApi.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace CarWashApi.Repositories
{
    public class WasherRepository : IWasherRepository
    {
        private readonly ApplicationDbContext _context;

        public WasherRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        // Fetch washer by Id and map it to WasherDTO with aggregated data
        public async Task<WasherDTO> GetWasherByIdAsync(int id)
        {
            // Query the User table and filter for users who are washers
            var user = await _context.Users
                .Where(u => u.UserId == id && u.IsWasher) // Filter only washers
                .Select(u => new WasherDTO
                {
                    WasherId = u.UserId,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Email = u.Email,
                    TotalOrders = _context.Orders.Count(o => o.UserId == u.UserId), // UserId to match orders
                    TotalAmount = _context.Orders.Where(o => o.UserId == u.UserId).Sum(o => o.TotalAmount),
                    AverageRating = _context.Reviews
                        .Where(r => r.Order.UserId == u.UserId) // Assuming each review is associated with an order, and the washer is the user of the order
                        .Average(r => (double?)r.Rating) ?? 0
                })
                .FirstOrDefaultAsync();

            return user;
        }
        public async Task<User> GetByIdAsync(int washerId)
    {
        return await _context.Users
                             .Where(u => u.UserId == washerId) // WasherId is essentially UserId
                             .FirstOrDefaultAsync();
    }
    }
}
