using Microsoft.EntityFrameworkCore;
using CarWashApi.Models;

namespace CarWashApi.Models
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Car> Cars { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<PackageDetail> PackageDetails { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Review> Reviews { get; set; }
         public DbSet<Admin> Admins { get; set; }
        

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
          protected override void OnModelCreating(ModelBuilder modelBuilder)
{
    base.OnModelCreating(modelBuilder);

    // Configure one-to-many relationships
    modelBuilder.Entity<Car>()
        .HasOne(c => c.User)
        .WithMany(u => u.Cars)
        .HasForeignKey(c => c.UserId)
        .OnDelete(DeleteBehavior.Restrict);  // Prevent cascading delete from Car to User

    modelBuilder.Entity<Order>()
        .HasOne(o => o.User)
        .WithMany(u => u.Orders)
        .HasForeignKey(o => o.UserId)
        .OnDelete(DeleteBehavior.Restrict);  // Prevent cascading delete from User to Order

    modelBuilder.Entity<Order>()
        .HasOne(o => o.Car)
        .WithMany(c => c.Orders)
        .HasForeignKey(o => o.CarId)
        .OnDelete(DeleteBehavior.Restrict);  // Prevent cascading delete from Car to Order

    modelBuilder.Entity<Order>()
        .HasOne(o => o.PackageDetail)
        .WithMany(p => p.Orders)
        .HasForeignKey(o => o.PackageId)
        .OnDelete(DeleteBehavior.Restrict);  // Prevent cascading delete from PackageDetail to Order

    modelBuilder.Entity<Review>()
        .HasOne(r => r.User)
        .WithMany(u => u.Reviews)
        .HasForeignKey(r => r.UserId)
        .OnDelete(DeleteBehavior.Restrict);  // Prevent cascading delete from User to Review

    modelBuilder.Entity<Review>()
        .HasOne(r => r.Washer)
        .WithMany()
        .HasForeignKey(r => r.WasherId)
        .OnDelete(DeleteBehavior.Restrict);  // Prevent cascading delete from Washer to Review

    modelBuilder.Entity<Review>()
        .HasOne(r => r.Order)
        .WithMany()
        .HasForeignKey(r => r.OrderId)
        .OnDelete(DeleteBehavior.Restrict);  // Prevent cascading delete from Order to Review

    modelBuilder.Entity<Payment>()
        .HasOne(p => p.Order)
        .WithMany()
        .HasForeignKey(p => p.OrderId)
        .OnDelete(DeleteBehavior.Restrict);  // Prevent cascading delete from Order to Payment

    modelBuilder.Entity<PackageDetail>()
        .HasMany(p => p.Orders)
        .WithOne(o => o.PackageDetail)
        .HasForeignKey(o => o.PackageId)
        .OnDelete(DeleteBehavior.Restrict);  // Prevent cascading delete from PackageDetail to Order

        modelBuilder.Entity<Review>()
       .Property(r => r.ReviewDate)
       .IsConcurrencyToken();
}



    }
}
