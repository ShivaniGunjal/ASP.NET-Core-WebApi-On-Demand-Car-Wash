using System.ComponentModel.DataAnnotations;

namespace CarWashApi.DTOs
{
    public class CarDTO
    {
        [Required(ErrorMessage = "UserId is required.")]
        public int UserId { get; set; }

        [Required(ErrorMessage = "Make is required.")]
        [StringLength(50, ErrorMessage = "Make cannot be longer than 50 characters.")]
        public string Make { get; set; }

        [Required(ErrorMessage = "Model is required.")]
        [StringLength(50, ErrorMessage = "Model cannot be longer than 50 characters.")]
        public string Model { get; set; }

        [Required(ErrorMessage = "Color is required.")]
        [StringLength(20, ErrorMessage = "Color cannot be longer than 20 characters.")]
        public string Color { get; set; }

    [Required(ErrorMessage = "LicensePlate is required.")]
    [StringLength(6, ErrorMessage = "LicensePlate must be exactly 6 characters.")]
    [RegularExpression(@"^[A-Za-z]{2}\d{4}$", ErrorMessage = "LicensePlate must consist of 2 letters followed by 4 digits.")]
    public string LicensePlate { get; set; }

        [StringLength(250, ErrorMessage = "Image URL cannot be longer than 250 characters.")]
        public string Image { get; set; }  // Nullable if not always provided
    }
}
