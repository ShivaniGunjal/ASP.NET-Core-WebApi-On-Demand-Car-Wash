using CarWashApi.DTOs;
using CarWashApi.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarWashApi.Repositories
{
    public class ReportRepository : IReportRepository
    {
        private readonly ApplicationDbContext _context;

        public ReportRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        // Generate Order Report by Date Range
        public async Task<List<Order>> GenerateOrderReportAsync(DateTime startDate, DateTime endDate)
        {
            return await _context.Orders
                .Include(o => o.User)            // Include User details (optional)
                .Include(o => o.PackageDetail)   // Include Package details (optional)
                .Where(o => o.OrderDate >= startDate && o.OrderDate <= endDate)
                .ToListAsync();
        }

        // Generate Washer Performance Report by Date Range
        public async Task<List<WasherDTO>> GenerateWasherReportAsync(DateTime startDate, DateTime endDate)
        {
            return await _context.Orders
                .Where(o => o.OrderDate >= startDate && o.OrderDate <= endDate)
                .GroupBy(o => o.UserId) // Group orders by WasherId
                .Select(g => new WasherDTO
                {
                    WasherId = g.Key != null ? Convert.ToInt32(g.Key) : 0,  // Explicitly cast g.Key to int
                    TotalOrders = g.Count(),
                    TotalAmount = g.Sum(o => o.TotalAmount),
                    // Assuming you have a Reviews collection on Order and each Review has a Rating
                    AverageRating = _context.Reviews
                        .Where(r => r.OrderId == (int)g.Key)  // Ensure g.Key is cast to int for proper comparison
                        .Average(r => r.Rating)  // Assuming Review has Rating
                })
                .ToListAsync();
        }
    }
}
