using CarWashApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CarWashApi.Repositories
{
    public interface IOrderRepository
    {
        Task<IEnumerable<Order>> GetAllOrdersAsync();
        Task<Order> GetOrderByIdAsync(int orderId);
        Task<List<Order>> GetOrdersByUserIdAsync(int userId);
        Task<IEnumerable<Order>> GetOrdersAssignedToWasherAsync(int washerId);
        Task<IEnumerable<Order>> GetCompletedOrdersByWasherAsync(int washerId);
        Task<Order> PlaceOrderAsync(Order order);
        Task<bool> UpdateOrderAsync(Order order);
        Task<bool> DeleteOrderAsync(int orderId);
        Task<PackageDetail> GetPackageDetailsByIdAsync(int packageId);
        Task<Order> GetByIdAsync(int orderId);
        
    }
}
