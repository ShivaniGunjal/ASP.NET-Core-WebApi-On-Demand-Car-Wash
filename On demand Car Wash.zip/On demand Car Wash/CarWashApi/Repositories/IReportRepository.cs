using CarWashApi.DTOs;
using CarWashApi.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CarWashApi.Repositories
{
    public interface IReportRepository
    {
        Task<List<Order>> GenerateOrderReportAsync(DateTime startDate, DateTime endDate);
        Task<List<WasherDTO>> GenerateWasherReportAsync(DateTime startDate, DateTime endDate);
    }
}
