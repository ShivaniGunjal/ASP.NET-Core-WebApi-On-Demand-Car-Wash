using CarWashApi.Models;
using Microsoft.EntityFrameworkCore;

namespace CarWashApi.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly ApplicationDbContext _context;
        
        public OrderRepository(ApplicationDbContext context)
        {
            _context = context;
            
        }

        public async Task<Order> PlaceOrderAsync(Order order)
        {
            _context.Orders.Add(order);
            await _context.SaveChangesAsync();
            return order;
        }

      public async Task<IEnumerable<Order>> GetAllOrdersAsync()
        {
            return await _context.Orders
                .Include(o => o.Car)
                .Include(o => o.PackageDetail)
                .ToListAsync();
        }

        public async Task<Order> GetOrderByIdAsync(int orderId)
        {
            return await _context.Orders
                .Include(o => o.Car)
                .Include(o => o.PackageDetail)
                .FirstOrDefaultAsync(o => o.OrderId == orderId);
        }
        public async Task<bool> ValidateUserExistence(int userId)
{
    return await _context.Users.AnyAsync(u => u.UserId == userId);
}

public async Task SaveOrderAsync(Order order)
{
    if (!await ValidateUserExistence(order.UserId))
    {
        throw new Exception("User does not exist.");
    }

    // Now you can safely add or update the order
    _context.Orders.Add(order);
    await _context.SaveChangesAsync();
}
public async Task<List<Order>> GetOrdersByUserIdAsync(int userId)
    {
        return await _context.Orders
            .Where(o => o.UserId == userId)
            .Include(o => o.Car)          // You can include related entities if needed
            .Include(o => o.PackageDetail) // Assuming you might need package details as well
            .ToListAsync();
    }

        public async Task<IEnumerable<Order>> GetOrdersAssignedToWasherAsync(int washerId)
        {
            return await _context.Orders
                .Where(o => o.UserId == washerId && o.Status != "Completed" )
                .ToListAsync();
        }

        public async Task<IEnumerable<Order>> GetCompletedOrdersByWasherAsync(int washerId)
        {
            return await _context.Orders
                .Where(o => o.UserId == washerId && o.Status == "Completed")
                .ToListAsync();
        }

        public async Task<bool> UpdateOrderAsync(Order order)
        {
            _context.Orders.Update(order);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> DeleteOrderAsync(int orderId)
        {
            var order = await _context.Orders.FindAsync(orderId);
            if (order == null) return false;

            _context.Orders.Remove(order);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<PackageDetail> GetPackageDetailsByIdAsync(int packageId)
        {
            return await _context.PackageDetails.FindAsync(packageId);

        }
        public async Task<Order> GetByIdAsync(int orderId)
        {
            return await _context.Orders.FindAsync(orderId);  // Use FindAsync to retrieve an order by its ID
        }
    }
}