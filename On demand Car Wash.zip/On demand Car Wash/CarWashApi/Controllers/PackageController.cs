using Microsoft.AspNetCore.Mvc;
using CarWashApi.Models;
using CarWashApi.DTOs;
using CarWashApi.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace CarWashApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PackageController : ControllerBase
    {
        private readonly IPackageDetailRepository _packageDetailRepository;

        // Constructor to inject the repository
        public PackageController(IPackageDetailRepository packageDetailRepository)
        {
            _packageDetailRepository = packageDetailRepository;
        }

        // GET: api/package
        [HttpGet]
        [Authorize(Policy = "CustomerOrAdmin")]
        
        public async Task<ActionResult<IEnumerable<PackageDetail>>> GetAllPackages()
        {
            var packages = await _packageDetailRepository.GetAllPackagesAsync();
            return Ok(packages); // Return the list of packages
        }

        // GET: api/package/{id}
        [HttpGet("{id}")]
        [Authorize(Policy = "CustomerOrAdmin")]
       
        public async Task<ActionResult<PackageDetail>> GetPackageById(int id)
        {
            var package = await _packageDetailRepository.GetPackageByIdAsync(id);

            if (package == null)
            {
                return NotFound($"Package with ID {id} not found."); // Return 404 if not found
            }

            return Ok(package); // Return the package
        }

        // POST: api/package
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<PackageDetail>> CreatePackage([FromBody] PackageDetailDTO packageDetailDTO)
        {
            if (packageDetailDTO == null)
            {
                return BadRequest("Package details cannot be null.");
            }

            // Validate the model automatically via model validation
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Return validation errors if the model is invalid
            }

            var createdPackage = await _packageDetailRepository.AddPackageAsync(packageDetailDTO);

            return CreatedAtAction(nameof(GetPackageById), new { id = createdPackage.PackageId }, createdPackage);
        }

        // PUT: api/package/{id}
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdatePackage(int id, [FromBody] PackageDetailDTO packageDetailDTO)
        {
            if (packageDetailDTO == null)
            {
                return BadRequest("Package details cannot be null.");
            }

            // Validate the model automatically via model validation
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Return validation errors if the model is invalid
            }

            var updatedPackage = await _packageDetailRepository.UpdatePackageAsync(id, packageDetailDTO);

            if (updatedPackage == null)
            {
                return NotFound($"Package with ID {id} not found.");
            }

            return NoContent(); // Return 204 if updated successfully
        }

        // DELETE: api/package/{id}
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeletePackage(int id)
        {
            var success = await _packageDetailRepository.DeletePackageAsync(id);

            if (!success)
            {
                return NotFound($"Package with ID {id} not found."); // Return 404 if package not found
            }

            return NoContent(); // Return 204 if successfully deleted
        }
    }
}
