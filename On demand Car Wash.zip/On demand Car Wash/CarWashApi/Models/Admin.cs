using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace CarWashApi.Models
{
    public class Admin
{
    public int AdminId { get; set; }  // Unique ID for the Admin
    public string Email { get; set; }  // Admin's email address
    public string Password { get; set; }  // Admin's password (ensure this is hashed/encrypted)
    public string Role {get; set; }
}

}
