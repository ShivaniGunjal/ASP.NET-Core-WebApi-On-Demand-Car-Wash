using CarWashApi.DTOs;
using CarWashApi.Models;
using CarWashApi.Repositories;
using CarWashApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;  // This is necessary to access IConfiguration


namespace CarWashApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WasherController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;
         private readonly IReviewRepository _reviewRepository;
        private readonly IWasherRepository _washerRepository;
        

        public WasherController(IOrderRepository orderRepository, IReviewRepository reviewRepository, IWasherRepository washerRepository)
        {
            _orderRepository = orderRepository;
            _reviewRepository = reviewRepository;
            _washerRepository = washerRepository;
            
            
        }

        [HttpGet("assigned-orders")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAssignedOrders(int washerId)
        {
            var orders = await _orderRepository.GetOrdersAssignedToWasherAsync(washerId);
            if (orders == null)
            {
                return NotFound("No orders assigned to you.");
            }
            return Ok(orders);
        }
        // Accept an unassigned order (this will assign the order to the washer)
        [HttpPut("accept-order/{orderId}")]
        [Authorize(Policy =  "WasherOnly")]
        public async Task<IActionResult> AcceptOrder(int orderId, int washerId)
        {
            var order = await _orderRepository.GetOrderByIdAsync(orderId);
            if (order == null)
            {
                return NotFound("Order not found.");
            }

            if (order.Status == "In Progress" || order.Status == "Completed")
            {
                return BadRequest("You cannot accept this order as it is already being processed or completed.");
            }

            // Assign the order to the washer
            order.UserId = washerId;
            order.Status = "Accepted";  // Mark as Accepted, or you can leave it as "Pending" and change later
            await _orderRepository.UpdateOrderAsync(order);

            return Ok("Order accepted and assigned to you.");
        }

        // Start washing an order (mark the order as "In Progress")
        [HttpPut("start-washing/{orderId}")]
        [Authorize(Policy = "WasherOnly")]
        public async Task<IActionResult> StartWashing(int orderId, int washerId)
        {
            var order = await _orderRepository.GetOrderByIdAsync(orderId);
            if (order == null)
            {
                return NotFound("Order not found.");
            }

            // Check if the order is already in progress or completed
            if (order.Status == "In Progress")
            {
                return BadRequest("This order is already in progress.");
            }

            if (order.Status == "Completed")
            {
                return BadRequest("This order has already been completed.");
            }

            // Check if the washer is assigned to this order
            if (order.UserId != washerId)
            {
                return Unauthorized("You are not assigned to this order.");
            }

            // Update the status to "In Progress"
            order.Status = "In Progress";
            await _orderRepository.UpdateOrderAsync(order);

            return Ok("Order status updated to 'In Progress'.");
        }

        [HttpPut("update-order-status/{orderId}")]
        [Authorize(Policy = "WasherOnly")]
        public async Task<IActionResult> UpdateOrderStatus(int orderId, [FromBody] OrderStatusDTO orderStatusDTO)
        {
            var order = await _orderRepository.GetOrderByIdAsync(orderId);
            if (order == null)
            {
                return NotFound("Order not found.");
            }

            if (orderStatusDTO.Status != "In Progress" && orderStatusDTO.Status != "Completed")
            {
                return BadRequest("Invalid status.");
            }

            order.Status = orderStatusDTO.Status;
            if (orderStatusDTO.Status == "Completed")
            {
                order.CompletedDate = DateTime.UtcNow;
               
               
            }

            await _orderRepository.UpdateOrderAsync(order);
            
            return Ok("Order status updated.");
        }
    
    }
}

