using CarWashApi.DTOs;
using CarWashApi.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarWashApi.Repositories
{
    public class CarRepository : ICarRepository
    {
        private readonly ApplicationDbContext _context;

        // Constructor that injects the ApplicationDbContext
        public CarRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        // Add a new car (Asynchronously)
        public async Task<Car> AddCarAsync(CarDTO carDTO)
        {
            // Create a new Car entity from the provided DTO
            var car = new Car
            {
                UserId = carDTO.UserId,
                Make = carDTO.Make,
                Model = carDTO.Model,
                Color = carDTO.Color,
                LicensePlate = carDTO.LicensePlate,
                Image = carDTO.Image
            };

            // Add the new car to the Cars DbSet and save the changes
            _context.Cars.Add(car);
            await _context.SaveChangesAsync();
            return car;
        }

        // Delete a car by its ID (Asynchronously)
        public async Task<bool> DeleteCarAsync(int carId)
        {
            // Find the car by its ID
            var car = await _context.Cars.FindAsync(carId);
            if (car == null)
                return false; // Return false if the car doesn't exist

            // Remove the car from the DbSet and save the changes
            _context.Cars.Remove(car);
            await _context.SaveChangesAsync();
            return true;
        }

        // Get a car by its make (Asynchronously)
        public async Task<Car> GetCarByMakeAsync(string make)
        {
            // Return the first car that matches the provided make (case-insensitive)
            return await _context.Cars
                .FirstOrDefaultAsync(c => c.Make.ToLower() == make.ToLower());
        }

        // Get all cars (Asynchronously)
        public async Task<IEnumerable<Car>> GetAllCarsAsync()
        {
            // Return all cars in the database
            return await _context.Cars.ToListAsync();
        }

        // Get a car by its ID (Asynchronously)
        public async Task<Car> GetCarByIdAsync(int carId)
        {
            // Return the car that matches the provided ID
            return await _context.Cars
                .FirstOrDefaultAsync(c => c.CarId == carId);
        }

        // Update an existing car's details (Asynchronously)
        public async Task<bool> UpdateCarAsync(int carId, CarDTO carDTO)
        {
            // Find the car by its ID
            var car = await _context.Cars.FindAsync(carId);
            if (car == null)
                return false; // Return false if the car doesn't exist

            // Update the car's properties with the provided values
            car.Make = carDTO.Make;
            car.Model = carDTO.Model;
            car.Color = carDTO.Color;
            car.LicensePlate = carDTO.LicensePlate;
            car.Image = carDTO.Image;

            // Save the changes to the database
            await _context.SaveChangesAsync();
            return true;
        }
}
}

