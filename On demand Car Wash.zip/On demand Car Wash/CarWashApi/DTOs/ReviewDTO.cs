using System;
using System.ComponentModel.DataAnnotations;

namespace CarWashApi.DTOs
{
    public class ReviewDTO
    {
       public int ReviewId { get; set; }
        public int UserId { get; set; }

        [Required]
        public int WasherId { get; set; }

        [Required]
        public int OrderId { get; set; }

        [Range(1, 5, ErrorMessage = "Rating must be between 1 and 5.")]
        public int Rating { get; set; }

        [MaxLength(500, ErrorMessage = "Comments cannot be more than 500 characters.")]
        public string Comments { get; set; }

        public DateTime ReviewDate { get; set; }=DateTime.UtcNow;
    }
}
