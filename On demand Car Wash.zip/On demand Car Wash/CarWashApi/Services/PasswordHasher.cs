// using CarWashApi.Models;
// using Microsoft.AspNetCore.Identity;

// namespace CarWashApi.Services
// {
//     public interface IPasswordHasher
//     {
//         string HashPassword(User user, string password);
//         bool VerifyPassword(User user, string password);
//     }

//     public class PasswordHasher : IPasswordHasher
//     {
//         private readonly IPasswordHasher<User> _passwordHasher;

//         public PasswordHasher(IPasswordHasher<User> passwordHasher)
//         {
//             _passwordHasher = passwordHasher;
//         }

//         public string HashPassword(User user, string password)
//         {
//             return _passwordHasher.HashPassword(user, password);
//         }

//         public bool VerifyPassword(User user, string password)
//         {
//             return _passwordHasher.VerifyHashedPassword(user, user.Password, password) == PasswordVerificationResult.Success;
//         }
//     }
// }
