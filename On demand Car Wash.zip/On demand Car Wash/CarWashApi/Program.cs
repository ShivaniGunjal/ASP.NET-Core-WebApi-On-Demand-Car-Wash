using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using CarWashApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using CarWashApi.Repositories;
using CarWashApi.Services;
using Microsoft.AspNetCore.Identity;

var builder = WebApplication.CreateBuilder(args);
//builder.Services.AddTransient<IEmailService, EmailService>();
builder.Services.AddTransient<IEmailService, EmailService>();

// Add services to the container.
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
);

builder.Services.AddScoped<IAdminRepository, AdminRepository>();
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<ICarRepository, CarRepository>();
 builder.Services.AddScoped<IPackageDetailRepository, PackageRepository>();
 builder.Services.AddScoped<IOrderRepository, OrderRepository>();
builder.Services.AddScoped<IPaymentRepository, PaymentRepository>();
builder.Services.AddScoped<IReviewRepository, ReviewRepository>();
builder.Services.AddScoped<IWasherRepository, WasherRepository>();
builder.Services.AddScoped<IPasswordHasher<User>, PasswordHasher<User>>();


// JWT Authentication Configuration
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.RequireHttpsMetadata = false;  // Change to true for production environments
        options.SaveToken = true;

        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Secret"])),
            ClockSkew = TimeSpan.FromMinutes(60) , // Allow 5 minutes of clock skew tolerance
            ValidAudience = builder.Configuration["Jwt:Audience"],  // This should match the audience in the JWT token
            ValidIssuer = builder.Configuration["Jwt:Issuer"]

        };
    });

// Add Authorization policies
builder.Services.AddAuthorization(options =>
{
    // Policy to check if the user is a washer
    options.AddPolicy("WasherOnly", policy => policy.RequireClaim("IsWasher", "True"));
    
    // Policy to check if the user is a customer
    options.AddPolicy("CustomerOnly", policy => policy.RequireClaim("IsWasher", "False"));
    options.AddPolicy("AdminOnly", policy => policy.RequireRole("Admin"));
     options.AddPolicy("CustomerOrAdmin", policy =>
            policy.RequireRole("Customer", "Admin"));
});


// Add controllers
builder.Services.AddControllers();

// Add Swagger generation with authorization support
builder.Services.AddEndpointsApiExplorer(); // This is required for .NET 6 and later
builder.Services.AddSwaggerGen(options =>
{
    // Add security definition for Bearer token
    options.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Description = "Please enter JWT with Bearer",
        Name = "Authorization",
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.ApiKey,
        BearerFormat = "JWT"
    });

    // Add security requirement to apply the Bearer token globally
    options.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new Microsoft.OpenApi.Models.OpenApiSecurityScheme
            {
                Reference = new Microsoft.OpenApi.Models.OpenApiReference
                {
                    Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[] {}
        }
    });
});

var app = builder.Build();

// Enable middleware to serve Swagger UI (HTML, JS, CSS, etc.)
if (app.Environment.IsDevelopment()) 
{
    app.UseSwagger(); // Generates Swagger JSON
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Car Wash API V1");
        c.RoutePrefix = string.Empty; // This will serve the Swagger UI at the root (localhost:5000)
    });
}

// Configure the HTTP request pipeline.
app.UseAuthentication(); // Adds the authentication middleware to the pipeline
app.UseAuthorization();  // Adds the authorization middleware to the pipeline

app.MapControllers();  // Maps controller routes

app.Run();  // Run the app
