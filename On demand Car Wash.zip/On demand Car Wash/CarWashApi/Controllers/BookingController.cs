

using CarWashApi.DTOs;
using CarWashApi.Models;
using CarWashApi.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CarWashApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;
        private readonly ILogger<BookingController> _logger;

        public BookingController(IOrderRepository orderRepository, ILogger<BookingController> logger)
        {
            _orderRepository = orderRepository;
            _logger = logger;
        }

        [HttpPost("place-order")]
        [Authorize(Policy = "CustomerOnly")]
        public async Task<IActionResult> PlaceOrder([FromBody] OrderDTO orderDTO)
        {
            if (orderDTO == null)
            {
                // Log and return a bad request if the order data is null
                _logger.LogError("Order data is required, request body is null.");
                return BadRequest("Order data is required.");
            }
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Return validation errors if any
            }

            // Fetch the package details from the database
            var packageDetails = await _orderRepository.GetPackageDetailsByIdAsync(orderDTO.PackageId);
            if (packageDetails == null)
            {
                // Log and return not found if the package is not found
                _logger.LogError($"Package with ID {orderDTO.PackageId} not found.");
                return NotFound($"Package with ID {orderDTO.PackageId} not found.");
            }

            // Validate UserId and CarId (ensure they are not 0)
            if (orderDTO.UserId == 0 || orderDTO.CarId == 0)
            {
                _logger.LogError("Invalid UserId or CarId. They must be valid and not zero.");
                return BadRequest("UserId and CarId must be valid.");
            }

            // Ensure TotalAmount is provided by the user and calculate total amount
            if (orderDTO.TotalAmount <= 0)
            {
                _logger.LogError("TotalAmount must be greater than zero.");
                return BadRequest("TotalAmount must be greater than zero.");
            }

            // Calculate total amount (price from the package + amount provided by the user)
            decimal totalAmount = orderDTO.TotalAmount + packageDetails.Price;

            // Create the order entity
            var order = new Order
            {
                UserId = orderDTO.UserId,
                CarId = orderDTO.CarId,
                PackageId = orderDTO.PackageId,
                Status = "Pending",  // Set initial status as "Pending"
                OrderDate = DateTime.UtcNow,  // Set current time as order date
                CompletedDate = DateTime.MinValue,  // Set CompletedDate to null initially
                TotalAmount = totalAmount  // Set the calculated total amount
            };

            try
            {
                // Place the order using the repository
                var placedOrder = await _orderRepository.PlaceOrderAsync(order);

                // Log the successful placement of the order
                _logger.LogInformation($"Order placed successfully with ID {placedOrder.OrderId}");

                // Map the Order entity to OrderDTO
                var orderResponse = new OrderDTO
                {
                    OrderId = placedOrder.OrderId,
                    UserId = placedOrder.UserId,
                    CarId = placedOrder.CarId,
                    PackageId = placedOrder.PackageId,
                    Status = placedOrder.Status,
                    OrderDate = placedOrder.OrderDate,
                    CompletedDate = placedOrder.CompletedDate,
                    TotalAmount = placedOrder.TotalAmount,

                };

                // Return the created order as a response with a 201 Created status
                return CreatedAtAction(nameof(GetOrderById), new { id = placedOrder.OrderId }, orderResponse);
            }
            catch (Exception ex)
            {
                // Log the error with the exception details
                _logger.LogError($"Error placing order: {ex.Message} - {ex.StackTrace}");
                if (ex.InnerException != null)
                {
                    _logger.LogError($"Inner Exception: {ex.InnerException.Message} - {ex.InnerException.StackTrace}");
                }

                // Return a generic error message to the client
                return StatusCode(500, "An error occurred while placing the order. Please try again later.");
            }
        }
        // Get order by id
        [HttpGet("{id}")]
        [Authorize(Policy = "CustomerOnly")]
        public async Task<IActionResult> GetOrderById(int id)
        {
            var order = await _orderRepository.GetOrderByIdAsync(id);
            if (order == null)
            {
                return NotFound("Order not found.");
            }

            // Map Order to OrderDTO
            var orderDTO = new OrderDTO
            {
                OrderId = order.OrderId,
                UserId = order.UserId,
                CarId = order.CarId,
                PackageId = order.PackageId,
                Status = order.Status,
                OrderDate = DateTime.UtcNow,  // Default to current time if null
                CompletedDate = order.CompletedDate, // Include CompletedDate if available
                TotalAmount = order.TotalAmount  // No need for ?? here, as TotalAmount is not nullable
            };

            return Ok(orderDTO);
        }
        [HttpGet("user-orders/{userId}")]
        [Authorize(Policy = "CustomerOnly")]
        public async Task<IActionResult> GetOrdersByUserId(int userId)
        {
            if (userId <= 0)
            {
                _logger.LogError("Invalid UserId provided.");
                return BadRequest("UserId must be valid.");
            }

            try
            {
                var orders = await _orderRepository.GetOrdersByUserIdAsync(userId);

                if (orders == null || !orders.Any())
                {
                    _logger.LogInformation($"No orders found for UserId {userId}.");
                    return NotFound($"No orders found for UserId {userId}.");
                }

                var orderDTOs = orders.Select(order => new OrderDTO
                {
                    OrderId = order.OrderId,
                    UserId = order.UserId,
                    CarId = order.CarId,
                    PackageId = order.PackageId,
                    Status = order.Status,
                    OrderDate = order.OrderDate,
                    CompletedDate = order.CompletedDate,
                    TotalAmount = order.TotalAmount
                }).ToList();

                return Ok(orderDTOs);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error fetching orders for UserId {userId}: {ex.Message} - {ex.StackTrace}");
                if (ex.InnerException != null)
                {
                    _logger.LogError($"Inner Exception: {ex.InnerException.Message} - {ex.InnerException.StackTrace}");
                }

                return StatusCode(500, "An error occurred while fetching the orders. Please try again later.");
            }
        }
    }
}