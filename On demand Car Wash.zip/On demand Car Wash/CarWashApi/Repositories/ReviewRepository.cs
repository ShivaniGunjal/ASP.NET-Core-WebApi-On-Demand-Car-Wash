using CarWashApi.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarWashApi.Repositories
{
    public class ReviewRepository : IReviewRepository
    {
        private readonly ApplicationDbContext _context;

        public ReviewRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        // 1. Create a new review
        public async Task<Review> CreateReviewAsync(Review review)
        {
            // Add the review to the context
            _context.Reviews.Add(review);
            await _context.SaveChangesAsync(); // Save changes to the database
            return review; // Return the created review
        }

        // 2. Get a review by ID
        public async Task<Review> GetReviewByIdAsync(int reviewId)
        {
            // Find the review by ID
            return await _context.Reviews
                .Include(r => r.User)   // Include related entities if needed (e.g., User)
                .Include(r => r.Washer) // Include related Washer (optional)
                .Include(r => r.Order)  // Include related Order (optional)
                .FirstOrDefaultAsync(r => r.ReviewId == reviewId); // Use FirstOrDefaultAsync to find the review
        }

        // 3. Get all reviews
        public async Task<List<Review>> GetAllReviewsAsync()
        {
            // Return all reviews from the database
            return await _context.Reviews
                .Include(r => r.User)   // Optional: Include related entities
                .Include(r => r.Washer)
                .Include(r => r.Order)
                .ToListAsync();
        }

        // 4. Get reviews by User ID
        public async Task<List<Review>> GetReviewsByUserIdAsync(int userId)
        {
            // Find all reviews written by a specific user (UserId)
            return await _context.Reviews
                .Where(r => r.UserId == userId)
                .Include(r => r.Washer) // Optionally include related entities
                .Include(r => r.Order)
                .ToListAsync();
        }

        // 5. Get reviews by Washer ID
        public async Task<List<Review>> GetReviewsByWasherIdAsync(int washerId)
        {
            // Find all reviews associated with a specific washer (WasherId)
            return await _context.Reviews
                .Where(r => r.WasherId == washerId)
                .Include(r => r.User)   // Optionally include related entities
                .Include(r => r.Order)
                .ToListAsync();
        }

        // 6. Update an existing review
        public async Task<Review> UpdateReviewAsync(Review review)
        {
            // Update the review in the context
            _context.Reviews.Update(review);
            await _context.SaveChangesAsync(); // Save changes to the database
            return review; // Return the updated review
        }

        // 7. Delete a review
        public async Task<bool> DeleteReviewAsync(int reviewId)
        {
            // Find the review by ID
            var review = await _context.Reviews.FindAsync(reviewId);
            if (review != null)
            {
                // Remove the review from the context and save changes
                _context.Reviews.Remove(review);
                await _context.SaveChangesAsync();
                return true; // Return true if the review was deleted
            }
            return false; // Return false if the review was not found
       
        }
          public async Task<Review> GetByIdAsync(int id)
    {
        return await _context.Reviews
            .Include(r => r.User)   // Include User details
            .Include(r => r.Washer) // Include Washer details
            .Include(r => r.Order)  // Include Order details
            .FirstOrDefaultAsync(r => r.ReviewId == id); // Fetch review by ID
    }

    public async Task CreateAsync(Review review)
    {
        await _context.Reviews.AddAsync(review);
        await _context.SaveChangesAsync();
    }
      public async Task<IEnumerable<Review>> GetAllAsync()
        {
            return await _context.Reviews.ToListAsync();  // Fetches all reviews from the database
        }  
       

    }
}