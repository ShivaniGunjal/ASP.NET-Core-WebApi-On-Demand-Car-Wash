using System;
using System.ComponentModel.DataAnnotations;

namespace CarWashApi.DTOs
{
    public class OrderDTO
    {
        public int OrderId { get; set; }

        [Required(ErrorMessage = "UserId is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "UserId must be greater than zero.")]
        public int UserId { get; set; }

        [Required(ErrorMessage = "CarId is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "CarId must be greater than zero.")]
        public int CarId { get; set; }

        [Required(ErrorMessage = "PackageId is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "PackageId must be greater than zero.")]
        public int PackageId { get; set; }

        [Required(ErrorMessage = "Status is required.")]
        [StringLength(50, ErrorMessage = "Status cannot be longer than 50 characters.")]
        public string Status { get; set; }

        [Required(ErrorMessage = "OrderDate is required.")]
        [CustomDateValidation(ErrorMessage = "OrderDate must be the current date.")]
        public DateTime? OrderDate { get; set; }

        [Required(ErrorMessage = "CompletedDate is required.")]
        [CustomCompletedDateValidation(ErrorMessage = "CompletedDate must be either the current date or a future date.")]
        public DateTime? CompletedDate { get; set; }

        [Required(ErrorMessage = "TotalAmount is required.")]
        [Range(0.01, double.MaxValue, ErrorMessage = "TotalAmount must be greater than zero.")]
        public decimal TotalAmount { get; set; }
    }

    // Custom validation for OrderDate
    public class CustomDateValidation : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value is DateTime dateTime)
            {
                return dateTime.Date == DateTime.UtcNow.Date;  // Only the current date
            }
            return false;
        }
    }

    // Custom validation for CompletedDate
    public class CustomCompletedDateValidation : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value is DateTime dateTime)
            {
                return dateTime.Date >= DateTime.UtcNow.Date;  // Current or future date
            }
            return false;
        }
    }
}
