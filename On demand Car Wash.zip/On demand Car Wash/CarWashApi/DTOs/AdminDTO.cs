using System.ComponentModel.DataAnnotations;

namespace CarWashApi.DTOs
{
    public class AdminDTO
    {
        [Key]
        public int AdminId { get; set; }  // Unique ID for the Admin

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email address format.")]
        [StringLength(255, ErrorMessage = "Email can't be longer than 255 characters.")]
        public string Email { get; set; }  // Admin's email address

       [Required(ErrorMessage = "Password is required.")]
        [RegularExpression(@"^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$", 
            ErrorMessage = "Password must contain at least one uppercase letter, one number, and one special character.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Role is required.")]
        [StringLength(50, ErrorMessage = "Role can't be longer than 50 characters.")]
        public string Role { get; set; }
    }
}
