using CarWashApi.DTOs;
using CarWashApi.Models;
using CarWashApi.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace CarWashApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReviewController : ControllerBase
    {
        private readonly IReviewRepository _reviewRepository;
        private readonly IUserRepository _userRepository;
        private readonly IOrderRepository _orderRepository;
        private readonly IWasherRepository _washerRepository;

        public ReviewController(
            IReviewRepository reviewRepository,
            IUserRepository userRepository,
            IOrderRepository orderRepository,
            IWasherRepository washerRepository)
        {
            _reviewRepository = reviewRepository;
            _userRepository = userRepository;
            _orderRepository = orderRepository;
            _washerRepository = washerRepository;
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllReviews()
        {
            var reviews = await _reviewRepository.GetAllAsync();  // Fetch all reviews

            if (reviews == null)
            {
                return NotFound();  // Return 404 if no reviews found
            }

            return Ok(reviews);  // Return HTTP 200 with all reviews
        }

        // Post create review
        [HttpPost]
        [Authorize(Policy = "CustomerOnly")]
        public async Task<IActionResult> CreateReview([FromBody] ReviewDTO reviewDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // You can map reviewDto to Review model and save it to the database
            var review = new Review
            {
                UserId = reviewDto.UserId,
                WasherId = reviewDto.WasherId,
                OrderId = reviewDto.OrderId,
                Rating = reviewDto.Rating,
                Comments = reviewDto.Comments,
                ReviewDate = reviewDto.ReviewDate
            };

            await _reviewRepository.CreateAsync(review);  // Save the review to the database

            return CreatedAtAction(nameof(GetAllReviews), new { id = review.ReviewId }, reviewDto);  // Return created status with location
        }
    }
}
