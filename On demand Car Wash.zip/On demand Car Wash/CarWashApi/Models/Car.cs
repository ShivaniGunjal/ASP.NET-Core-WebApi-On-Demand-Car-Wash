using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CarWashApi.Models
{
    public class Car
    {
        [Key]
        public int CarId { get; set; }
        
        public int UserId { get; set; }  // Foreign key to User
        
        [Required]
        public string Make { get; set; }
        
        [Required]
        public string Model { get; set; }
        
        [Required]
        public string Color { get; set; }
        
        [Required]
        public string LicensePlate { get; set; }
        
        
        public string Image { get; set; }

        // Navigation property
        public User User { get; set; }  // Many Cars belong to one User
        public ICollection<Order> Orders { get; set; }
    }
}
