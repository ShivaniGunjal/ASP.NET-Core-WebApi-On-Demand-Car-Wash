using CarWashApi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CarWashApi.Repositories
{
    public interface IPaymentRepository
    {
        Task<Payment> MakePaymentAsync(Payment payment);
        Task<IEnumerable<Payment>> GetPaymentsByUserIdAsync(int userId);
        Task<Payment> GetPaymentByOrderIdAsync(int orderId);
        Task<IEnumerable<Payment>> GetAllPaymentsAsync();
    }
}
