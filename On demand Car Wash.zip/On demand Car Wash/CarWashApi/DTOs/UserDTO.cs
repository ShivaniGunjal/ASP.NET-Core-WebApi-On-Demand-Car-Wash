using System.ComponentModel.DataAnnotations;
using CarWashApi.DTOs;

namespace CarWashApi.Models
{
    public class UserDTO
    { 
        

        [Required(ErrorMessage = "First Name is required.")]
        [StringLength(100, ErrorMessage = "First Name cannot be longer than 100 characters.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last Name is required.")]
        [StringLength(100, ErrorMessage = "Last Name cannot be longer than 100 characters.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid Email Address.")]
        [StringLength(255, ErrorMessage = "Email cannot be longer than 255 characters.")]
        public string Email { get; set; }

        
        public long PhoneNumber { get; set; }

        [StringLength(500, ErrorMessage = "Address cannot be longer than 500 characters.")]
        public string Address { get; set; }

        // Default value can be set, if needed.
        public bool IsActive { get; set; } = true;

        // Default value for IsWasher (typically a washer can be set to false initially)
        public bool IsWasher { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [StringLength(100, MinimumLength = 6, ErrorMessage = "Password must be between 6 and 100 characters.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }


         //public UserDTO User { get; set; }
         //public List<OrderDTO> Orders { get; set; }

    }
}
