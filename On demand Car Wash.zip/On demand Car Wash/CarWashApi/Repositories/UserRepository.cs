// UserRepository.cs
using CarWashApi.Models;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace CarWashApi.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly ApplicationDbContext _context;

        public UserRepository(ApplicationDbContext context)
        {
            _context = context;
        }
        // Register a new user
        public async Task<User> RegisterUserAsync(UserDTO userDTO)
        {
            var user = new User
            {
                FirstName = userDTO.FirstName,
                LastName = userDTO.LastName,
                Email = userDTO.Email,
                PhoneNumber = userDTO.PhoneNumber,
                IsActive = userDTO.IsActive,
                IsWasher = userDTO.IsWasher,
                Password = BCrypt.Net.BCrypt.HashPassword(userDTO.Password),
                Address = userDTO.Address
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return user;
        }
        // Get user by email for login
        public async Task<User> GetUserByEmailAsync(string email)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
        }

        // Get user profile by userId (async method)
        public async Task<UserDTO> GetUserProfileAsync(int userId)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null)
                return null;  // Handle user not found

            // Map the user to a UserDTO
            return new UserDTO
            {
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber,
                Address = user.Address
            };
        }

        public async Task<bool> UpdateUserProfileAsync(int userId, UserDTO userDTO)
        {
            // Find the user by userId
            var user = await _context.Users.FindAsync(userId);

            // If user is not found, return false
            if (user == null)
                return false;

            // Update the user's profile information
            user.FirstName = userDTO.FirstName;
            user.LastName = userDTO.LastName;
            user.Email = userDTO.Email;
            user.PhoneNumber = userDTO.PhoneNumber;
            user.Address = userDTO.Address;
            user.IsActive = userDTO.IsActive;

            // Save the updated user to the database
            _context.Users.Update(user);
            await _context.SaveChangesAsync();

            return true;
        }
    



        public async Task<User> CreateUserAsync(User user)
        {
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return user;
        }

        public async Task<User> GetUserByIdAsync(int userId)
        {
            return await _context.Users.FindAsync(userId);
        }

        public async Task<User> GetUserByNameAsync(string name)
        {
            return await _context.Users
                .FirstOrDefaultAsync(u => u.FirstName == name || u.LastName == name);
        }

        public async Task<bool> DeactivateUserByNameAsync(string name)
        {
            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.FirstName == name || u.LastName == name);

            if (user == null)
                return false;

            _context.Users.Remove(user);  // Or set user.IsActive = false if you're not removing the user
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<User> AssignRoleByNameAsync(string name, string role)
        {
            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.FirstName == name || u.LastName == name);

            if (user == null)
                return null;

            await _context.SaveChangesAsync();
            return user;
        }
        public async Task<List<Review>> GetUserReviewsAsync(int userId)
        {
            return await _context.Reviews
                                 .Where(r => r.UserId == userId)
                                 .ToListAsync();
        }
        public async Task<User> GetByIdAsync(int userId)
        {
            return await _context.Users.FindAsync(userId);  // Use FindAsync to retrieve a user by their ID
        }
    }
}
