using CarWashApi.Models;
using CarWashApi.DTOs;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace CarWashApi.Repositories
{
    
    public class PackageRepository : IPackageDetailRepository
    {
        private readonly ApplicationDbContext _context;

        public PackageRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<PackageDetail>> GetAllPackagesAsync()
        {
            return await _context.PackageDetails.ToListAsync();
        }

        public async Task<PackageDetail> GetPackageByIdAsync(int packageId)
        {
            return await _context.PackageDetails.FirstOrDefaultAsync(p => p.PackageId == packageId);
        }

        public async Task<PackageDetail> GetPackageByNameAsync(string packageName)
        {
            return await _context.PackageDetails
                .FirstOrDefaultAsync(p => p.PackageName.ToLower() == packageName.ToLower());
        }

        public async Task<PackageDetail> AddPackageAsync(PackageDetailDTO packageDetailDTO)
        {
            var packageDetail = new PackageDetail
            {
                PackageName = packageDetailDTO.PackageName,
                
                Price = packageDetailDTO.Price,
                IsActive = packageDetailDTO.IsActive
                // No need to manually initialize Orders; it's already done in the model.
            };

            // Add the new package to the database
            _context.PackageDetails.Add(packageDetail);
            await _context.SaveChangesAsync();  // Save changes to the database

            return packageDetail;  // Return the newly created package
        }

        public async Task<PackageDetail> UpdatePackageAsync(int packageId, PackageDetailDTO packageDTO)
        {
            var package = await _context.PackageDetails.FindAsync(packageId);
            if (package == null) return null;

            package.PackageName = packageDTO.PackageName;
            package.Price = packageDTO.Price;
            package.IsActive = packageDTO.IsActive;

            await _context.SaveChangesAsync();
            return package;
        }

        public async Task<bool> DeletePackageAsync(int packageId)
        {
            var package = await _context.PackageDetails.FindAsync(packageId);
            if (package == null) return false;

            _context.PackageDetails.Remove(package);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}

