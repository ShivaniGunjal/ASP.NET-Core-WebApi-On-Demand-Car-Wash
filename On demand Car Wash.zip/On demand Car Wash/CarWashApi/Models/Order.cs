using System.ComponentModel.DataAnnotations;

namespace CarWashApi.Models
{
    public class Order
    {
        [Key]
        public int OrderId { get; set; }
        
        public int UserId { get; set; }  // Foreign key to User
        public int CarId { get; set; }  // Foreign key to Car
        public  int PackageId { get; set; }
        public string Status { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime CompletedDate { get; set; }
        public decimal TotalAmount { get; set; }

        // Navigation properties
        public  User User { get; set; }
        public  Car Car { get; set; }
        public PackageDetail PackageDetail { get; set; }
    }
}
