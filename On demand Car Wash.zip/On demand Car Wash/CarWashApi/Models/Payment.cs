using System.ComponentModel.DataAnnotations;

namespace CarWashApi.Models
{
    public class Payment
    {
        [Key]
        public int PaymentId { get; set; }
        
        public int OrderId { get; set; }  // Foreign key to Order
        
        public decimal Amount { get; set; }
        
        [Required]
        public  string PaymentMethod { get; set; }
        public string PaymentStatus { get; set; }
        public DateTime PaymentDate { get; set; }

        // Navigation property
        public Order Order { get; set; }
        public int UserId { get; set; }
    }
}
