using System.ComponentModel.DataAnnotations;

namespace CarWashApi.DTOs
{
    public class WasherDTO
    {
        public int WasherId { get; set; }

        [Required(ErrorMessage = "First Name is required.")]
        [StringLength(100, ErrorMessage = "First Name can't be longer than 100 characters.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last Name is required.")]
        [StringLength(100, ErrorMessage = "Last Name can't be longer than 100 characters.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email format.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Phone Number is required.")]
        [Phone(ErrorMessage = "Invalid phone number format.")]
        public string PhoneNumber { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Total Orders must be a non-negative number.")]
        public int TotalOrders { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "Total Amount must be a non-negative number.")]
        public decimal TotalAmount { get; set; }

        [Range(0, 5, ErrorMessage = "Average Rating must be between 0 and 5.")]
        public double AverageRating { get; set; }
    }
}
