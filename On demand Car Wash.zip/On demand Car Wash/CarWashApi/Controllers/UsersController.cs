using CarWashApi.DTOs;
using CarWashApi.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using CarWashApi.Models;
using CarWashApi.Services;
using Microsoft.AspNetCore.Identity;

namespace CarWashApi.Controllers
{
    [Route("api/users")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private readonly IConfiguration _configuration;
        private readonly IReviewRepository _reviewRepository;
        private readonly IWasherRepository _washerRepository;
        private readonly IOrderRepository _orderRepository;
        private readonly ILogger<UserController> _logger;
        private readonly IEmailService _emailService;


        public UserController(IUserRepository userRepository, IConfiguration configuration, ILogger<UserController> logger, IReviewRepository reviewRepository, IWasherRepository washerRepository, IOrderRepository orderRepository, IEmailService emailService)
        {
            _userRepository = userRepository;
            _configuration = configuration;
            _reviewRepository = reviewRepository;
            _washerRepository = washerRepository;
            _orderRepository = orderRepository;
            _logger = logger;
            _emailService = emailService;

        }
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] UserDTO userDTO)
        {
            _logger.LogInformation("Registering user with Email: {Email}", userDTO.Email);

            if (!ModelState.IsValid)
            {
                _logger.LogError("Validation failed for User Registration.");
                return BadRequest(ModelState);
            }


            var registeredUser = await _userRepository.RegisterUserAsync(userDTO);
            if (registeredUser == null)
            {
                _logger.LogError("User Registration failed for Email: {Email}", userDTO.Email);
                return BadRequest("User could not be created.");
            }

            _logger.LogInformation("User successfully registered with UserId: {UserId}", registeredUser.UserId);

            try
            {
                // Send Registration Email (passing false for registration)
                await _emailService.SendEmail(registeredUser, isLoginEmail: false);
                _logger.LogInformation("Registration email sent successfully to Email: {Email}", registeredUser.Email);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to send registration email to Email: {Email}. Error: {Error}", registeredUser.Email, ex.Message);
            }
            // Generate JWT token for the newly registered user
            var token = GenerateJwtToken(registeredUser.UserId, registeredUser.FirstName, registeredUser.LastName, registeredUser.Email, registeredUser.IsWasher);


            // Return a UserDTO for the registered user
            var registeredUserDTO = MapToDTO(registeredUser);
            return Ok(new { Message = "Registration Successful", Token = token, User = registeredUserDTO });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] UserLoginDTO loginDTO)
        {
            _logger.LogInformation("User login attempt with Email: {Email}", loginDTO.Email);

            // Fetch the user from the database using email
            var user = await _userRepository.GetUserByEmailAsync(loginDTO.Email);
            // if (user == null || user.Password != loginDTO.Password)
            // Directly comparing plain-text passwords
            if (user == null || !BCrypt.Net.BCrypt.Verify(loginDTO.Password, user.Password))
            {
                _logger.LogWarning("Login failed for Email: {Email}. Invalid credentials.", loginDTO.Email);
                return Unauthorized("Invalid credentials.");
            }

            _logger.LogInformation("User logged in successfully with UserId: {UserId}", user.UserId);

            try
            {
                // Send Login Email (passing true for login)
                await _emailService.SendEmail(user, isLoginEmail: true);
                _logger.LogInformation("Login email sent successfully to Email: {Email}", user.Email);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to send login email to Email: {Email}. Error: {Error}", user.Email, ex.Message);
            }
            // Generate JWT token
            var token = GenerateJwtToken(user.UserId, user.FirstName, user.LastName, user.Email, user.IsWasher);

            // Send the login notification email


            // Return a message based on the user role
            string roleMessage = user.IsWasher ? "Washer login successful" : "Customer login successful";
            return Ok(new { Message = roleMessage, Token = token });
        }



        // Get the authenticated user's profile (requires authentication)
        [HttpGet("profile")]
        [Authorize(Policy = "CustomerOnly")]  // Only authenticated users can access this
        public async Task<IActionResult> GetProfile()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(userIdClaim))
            {
                _logger.LogWarning("User ID claim missing or invalid in the JWT.");
                return Unauthorized("User not authenticated.");
            }

            var userId = int.Parse(userIdClaim);  // Get userId from JWT claims

            var userProfile = await _userRepository.GetUserProfileAsync(userId);
            if (userProfile == null)
            {
                return NotFound("User profile not found.");
            }

            return Ok(userProfile);
        }
        [HttpPut("update-profile")]
        [Authorize(Policy = "CustomerOnly")]
        public async Task<IActionResult> UpdateProfile([FromBody] UserDTO userDTO)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogError("Validation failed for Update Profile.");
                return BadRequest(ModelState);  // Return the validation errors as part of the response
            }
            // Get the userId from the JWT claim
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(userIdClaim))
            {
                _logger.LogWarning("User ID claim missing or invalid in the JWT.");
                return Unauthorized("User not authenticated.");
            }

            var userId = int.Parse(userIdClaim);  // Get userId from JWT claims

            // Update the user profile
            var updated = await _userRepository.UpdateUserProfileAsync(userId, userDTO);

            if (!updated)
            {
                return NotFound("User profile not found.");
            }

            return Ok("Profile updated successfully.");
        }

        

        // 1. Create a new review
        [HttpPost]
        [Authorize(Policy = "CustomerOnly")]
        public async Task<IActionResult> CreateReview([FromBody] ReviewDTO reviewDto)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogError("Validation failed for Create Profile.");
                return BadRequest(ModelState);  // Return the validation errors as part of the response
            }
            if (reviewDto == null)
                return BadRequest("Review data is required.");

            // Retrieve entities to validate User, Washer, and Order
            var user = await _userRepository.GetByIdAsync(reviewDto.UserId);
            var order = await _orderRepository.GetByIdAsync(reviewDto.OrderId);

            if (user == null || order == null)
                return NotFound("User, or Order not found.");

            var review = new Review
            {
                UserId = reviewDto.UserId,
                WasherId = reviewDto.WasherId,
                OrderId = reviewDto.OrderId,
                Rating = reviewDto.Rating,
                Comments = reviewDto.Comments ?? "No comments",
                ReviewDate = DateTime.UtcNow
            };

            await _reviewRepository.CreateReviewAsync(review);
            return Ok(review);
        }

        // 2. Get all reviews by the current user
        [HttpGet("reviews")]
        [Authorize(Policy = "CustomerOnly")]
        public async Task<IActionResult> GetReviewsByUserId()
        {
            var userId = int.Parse(User.Identity.Name);  // Assuming the UserId is stored in the User.Identity
            var reviews = await _reviewRepository.GetReviewsByUserIdAsync(userId);

            if (reviews == null || reviews.Count == 0)
                return NotFound("No reviews found.");
            return Ok(reviews);
        }

        // 3. Update a review
        [HttpPut("{reviewId}")]
        [Authorize(Policy = "CustomerOnly")]
        public async Task<IActionResult> UpdateReview(int reviewId, [FromBody] ReviewDTO reviewDto)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogError("Validation failed for Update Review.");
                return BadRequest(ModelState);  // Return the validation errors as part of the response
            }
            var review = await _reviewRepository.GetReviewByIdAsync(reviewId);
            if (review == null)
                return NotFound("Review not found.");

            // Only the user who created the review should be allowed to update it
            var userId = int.Parse(User.Identity.Name);
            if (review.UserId != userId)
                return Unauthorized("You can only edit your own reviews.");

            review.Rating = reviewDto.Rating;
            review.Comments = reviewDto.Comments;
            review.ReviewDate = DateTime.UtcNow;

            await _reviewRepository.UpdateReviewAsync(review);
            return Ok(review);
        }


        private string GenerateJwtToken(int userId, string firstName, string lastName, string email, bool isWasher)
        {
            _logger.LogInformation("Generating JWT token for UserId: {UserId}, FirstName: {FirstName}, LastName: {LastName}, Email: {Email}, IsWasher: {IsWasher}", userId, firstName, lastName, email, isWasher);

            // Ensure none of the parameters are null or empty
            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName) || string.IsNullOrEmpty(email))
            {
                _logger.LogError("Cannot generate JWT token: Missing required information (FirstName, LastName, Email).");
                throw new ArgumentNullException("FirstName, LastName, and Email are required to generate a JWT token.");
            }

            // Get SecretKey from configuration
            var secretKey = _configuration["Jwt:Secret"];
            if (string.IsNullOrEmpty(secretKey))
            {
                _logger.LogError("JWT SecretKey is null or empty. Please check your configuration.");
                throw new InvalidOperationException("SecretKey cannot be null or empty.");
            }

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            // Add the "IsWasher" claim
            var claims = new[]
            {
        new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
        new Claim(ClaimTypes.Name, firstName),
        new Claim(ClaimTypes.Surname, lastName),
        new Claim(ClaimTypes.Email, email),
        new Claim("IsWasher", isWasher.ToString()),
         new Claim(ClaimTypes.Role, isWasher ? "Washer" : "Customer"),
         new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
    };

            var token = new JwtSecurityToken(
                _configuration["Jwt:Issuer"],
                _configuration["Jwt:Audience"],
                claims,
                expires: DateTime.Now.AddMinutes(Convert.ToInt32(_configuration["Jwt:ExpirationInMinutes"])),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
        private UserDTO MapToDTO(User user)
        {
            return new UserDTO
            {
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber,
                Address = user.Address,
                IsWasher = user.IsWasher,
                IsActive = user.IsActive
            };
        }
    }
}