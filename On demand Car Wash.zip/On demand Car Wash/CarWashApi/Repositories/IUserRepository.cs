// IUserRepository.cs
using CarWashApi.Models;
using System.Threading.Tasks;

namespace CarWashApi.Repositories
{
    public interface IUserRepository
    {
        Task<User> CreateUserAsync(User user);
        Task<User> GetUserByIdAsync(int userId);
        Task<bool> DeactivateUserByNameAsync(string name);


        Task<User> AssignRoleByNameAsync(string name, string role); // Corrected method name
        Task<User> GetUserByNameAsync(string name);
        Task<List<Review>> GetUserReviewsAsync(int userId);
        Task<User> RegisterUserAsync(UserDTO userDTO);
        Task<User> GetUserByEmailAsync(string email);
        Task<UserDTO> GetUserProfileAsync(int userId);
        Task<bool> UpdateUserProfileAsync(int userId, UserDTO userDTO);
        Task<User> GetByIdAsync(int userId);
    


    }
}
