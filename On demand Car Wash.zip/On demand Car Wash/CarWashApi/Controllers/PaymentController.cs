using Microsoft.AspNetCore.Mvc;
using CarWashApi.Models;
using CarWashApi.DTOs;
using CarWashApi.Repositories;
using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace CarWashApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly IPaymentRepository _paymentRepository;

        public PaymentController(IPaymentRepository paymentRepository)
        {
            _paymentRepository = paymentRepository;
        }

        // Make a payment based on the selected method
        [HttpPost("make-payment")]
        [Authorize(Policy = "CustomerOnly")]
        public async Task<IActionResult> MakePayment([FromBody] PaymentDTO paymentDTO)
        {
            if (paymentDTO == null)
            {
                return BadRequest("Invalid payment data.");
            }

            // Validate payment method
            if (!IsValidPaymentMethod(paymentDTO.PaymentMethod))
            {
                return BadRequest("Invalid payment method. Allowed methods are GPay, PhonePe, UPI, NetBanking.");
            }

            // Check model state for validation errors
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Return validation errors if the model is invalid
            }

            // Get the userId from the authenticated user (from JWT claims)
            var userIdClaim = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier);
            if (userIdClaim == null)
            {
                return Unauthorized("User is not authenticated.");
            }

            int userId = Convert.ToInt32(userIdClaim.Value);  // Extract userId from the claim

            // Set initial payment status to "Pending"
            string paymentStatus = "Pending";

            try
            {
                // Simulate processing the payment based on selected method
                paymentStatus = await ProcessPaymentAsync(paymentDTO.PaymentMethod);

                // Convert PaymentDTO to Payment model for database operation
                var payment = new Payment
                {
                    OrderId = paymentDTO.OrderId,
                    Amount = paymentDTO.Amount,
                    PaymentMethod = paymentDTO.PaymentMethod,
                    PaymentDate = DateTime.UtcNow, // Use current time
                    PaymentStatus = paymentStatus,  // Set the payment status based on result
                    UserId = userId  // Use the authenticated user's ID
                };

                var savedPayment = await _paymentRepository.MakePaymentAsync(payment);

                // Return the payment along with the payment status in the response
                return Ok(new
                {
                    OrderId = savedPayment.OrderId,
                    Amount = savedPayment.Amount,
                    PaymentMethod = savedPayment.PaymentMethod,
                    PaymentDate = savedPayment.PaymentDate,
                    PaymentStatus = savedPayment.PaymentStatus // Returning the actual payment status
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // Get all payments by user ID
        [HttpGet("payments")]
        [Authorize(Policy = "CustomerOnly")]
        public async Task<IActionResult> GetPaymentsByUserId()
        {
            // Get the userId from the authenticated user (from JWT claims)
            var userIdClaim = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier);
            if (userIdClaim == null)
            {
                return Unauthorized("User is not authenticated.");
            }

            int userId = Convert.ToInt32(userIdClaim.Value);  // Extract userId from the claim

            try
            {
                var payments = await _paymentRepository.GetPaymentsByUserIdAsync(userId);
                if (payments == null || !payments.Any())
                {
                    return NotFound("No payments found for this user.");
                }
                return Ok(payments);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("payment/{orderId}")]
        [Authorize(Policy = "CustomerOnly")]
        public async Task<IActionResult> GetPaymentByOrderId(int orderId)
        {
            var userIdClaim = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier);
            if (userIdClaim == null)
            {
                return Unauthorized("User is not authenticated.");
            }

            int userId = Convert.ToInt32(userIdClaim.Value);  // Extract userId from the claim
            Console.WriteLine($"Authenticated userId: {userId}"); // Log userId for debugging

            try
            {
                var payment = await _paymentRepository.GetPaymentByOrderIdAsync(orderId);
                if (payment == null)
                {
                    return NotFound("Payment not found for this order.");
                }

                Console.WriteLine($"Payment found with UserId: {payment.UserId}"); // Log the payment's UserId

                // Check if the payment belongs to the authenticated user
                if (payment.UserId != userId)
                {
                    return Unauthorized("You are not authorized to view this payment.");
                }

                return Ok(payment);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // Check if payment method is valid
        private bool IsValidPaymentMethod(string paymentMethod)
        {
            var validMethods = new[] { "GPay", "PhonePe", "UPI", "NetBanking" };
            return validMethods.Contains(paymentMethod);
        }

        // Simulate processing the payment and set status
        private async Task<string> ProcessPaymentAsync(string paymentMethod)
        {
            // Simulate different payment methods processing
            switch (paymentMethod)
            {
                case "GPay":
                    // Simulate processing GPay
                    await Task.Delay(500); // Simulate async call
                    return "Completed";  // Payment successful

                case "PhonePe":
                    // Simulate processing PhonePe
                    await Task.Delay(500); // Simulate async call
                    return "Completed";  // Payment successful

                case "UPI":
                    // Simulate processing UPI
                    await Task.Delay(500); // Simulate async call
                    return "Completed";  // Payment successful

                case "NetBanking":
                    // Simulate processing NetBanking
                    await Task.Delay(500); // Simulate async call
                    return "Completed";  // Payment successful

                default:
                    return "Failed";  // Invalid payment method
            }
        }
    }
}
