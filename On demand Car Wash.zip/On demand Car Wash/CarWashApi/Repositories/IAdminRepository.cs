using CarWashApi.Models;

namespace CarWashApi.Repositories
{
    public interface IAdminRepository
    {
            Task<Admin> GetAdminByEmailAsync(string email);
            Task AddAdminAsync(Admin admin);
        
    }
}


