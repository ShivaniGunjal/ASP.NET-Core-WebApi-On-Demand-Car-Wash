using System.ComponentModel.DataAnnotations;

namespace CarWashApi.Models
{
    public class Review
    {
        [Key]
        public int ReviewId { get; set; }
        
        public int UserId { get; set; }  // Foreign key to User (the person who wrote the review)
        public int WasherId { get; set; }  // Foreign key to Washer (assumed to be a User)
        public int OrderId { get; set; }  // Foreign key to Order
        
        public int Rating { get; set; }
        
        [Required]
        public  string Comments { get; set; }
        
        public DateTime ReviewDate { get; set; }

        // Navigation properties
        public  User User { get; set; }
        public  User Washer { get; set; }  // Assuming Washer is also a User (car washer)
        public  Order Order { get; set; }
    }
}
