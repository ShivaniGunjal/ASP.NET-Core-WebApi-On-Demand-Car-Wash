namespace CarWashApi.DTOs
{
    public class UpdatePhoneNumberDTO
    {
        public long PhoneNumber { get; set; }
    }
}
