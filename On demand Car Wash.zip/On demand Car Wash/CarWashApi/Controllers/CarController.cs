using CarWashApi.DTOs;
using CarWashApi.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace CarWashApi.Controllers
{
    [Route("api/cars")]
    [ApiController]
    public class CarController : ControllerBase
    {
        private readonly ICarRepository _carRepository;
        private readonly ILogger<CarController> _logger;

        public CarController(ICarRepository carRepository, ILogger<CarController> logger)
        {
            _carRepository = carRepository;
            _logger = logger;
        }

        // Add a car (POST)
        [HttpPost]
        [Authorize(Policy = "CustomerOnly")]  // Requires authentication
        public async Task<IActionResult> AddCar([FromBody] CarDTO carDTO)
        {
            if (carDTO == null)
            {
                return BadRequest("Car details are required.");
            }

            // Validate the CarDTO model
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);  // Return validation errors if any
            }

            try
            {
                var car = await _carRepository.AddCarAsync(carDTO);
                return CreatedAtAction(nameof(GetCarById), new { carId = car.CarId }, car);
            }
            catch (Exception ex)
            {
                // If the exception message is about an invalid UserId
                if (ex.Message.Contains("User with the specified UserId"))
                {
                    return BadRequest(ex.Message);  // Return the error message from the exception
                }

                // Generic error handling
                return StatusCode(500, "An unexpected error occurred.");
            }
        }

        // Get all cars (GET)
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllCars()
        {
            var cars = await _carRepository.GetAllCarsAsync();
            return Ok(cars);
        }

        // Get a car by make (GET)
        [HttpGet("make/{make}")]
        [Authorize(Policy = "CustomerOnly")]  // Requires authentication
        public async Task<IActionResult> GetCarByMake(string make)
        {
            var car = await _carRepository.GetCarByMakeAsync(make);
            if (car == null)
                return NotFound("Car not found.");
            return Ok(car);
        }

        // Get a car by ID (GET)
        [HttpGet("{carId}")]
        [Authorize(Policy = "CustomerOnly")]
        public async Task<IActionResult> GetCarById(int carId)
        {
            var car = await _carRepository.GetCarByIdAsync(carId);
            if (car == null)
                return NotFound("Car not found.");
            return Ok(car);
        }

        // Update a car (PUT)
        [HttpPut("{carId}")]
        [Authorize(Policy = "CustomerOnly")]
        public async Task<IActionResult> UpdateCar(int carId, [FromBody] CarDTO carDTO)
        {
            if (carDTO == null)
            {
                return BadRequest("Car details are required.");
            }

            // Validate the CarDTO model
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);  // Return validation errors if any
            }

            var updated = await _carRepository.UpdateCarAsync(carId, carDTO);
            if (!updated)
                return NotFound("Car not found.");
            return Ok("Car updated successfully.");
        }

        // Delete a car (DELETE)
        [HttpDelete("{carId}")]
        [Authorize(Policy = "CustomerOnly")]  // Requires authentication
        public async Task<IActionResult> DeleteCar(int carId)
        {
            var deleted = await _carRepository.DeleteCarAsync(carId);
            if (!deleted)
                return NotFound("Car not found.");
            return Ok("Car deleted successfully.");
        }
    }
}
