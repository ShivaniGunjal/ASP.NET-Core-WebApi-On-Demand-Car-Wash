// using CarWashApi.Repositories;
// using CarWashApi.Services;
// using Microsoft.AspNetCore.Identity;
// using CarWashApi.Models;
// using System.Threading.Tasks;
// using CarWashApi.DTOs;
// using Microsoft.Extensions.Logging;
// using Microsoft.Extensions.Configuration;

// namespace CarWashApi.Services
// {
//     public class AuthenticationService
//     {
//         private readonly IUserRepository _userRepository;
//         private readonly IPasswordHasher<Admin> _passwordHasher;
//         private readonly JwtTokenService _jwtTokenService;
//         private readonly ILogger<AuthenticationService> _logger;

//         public AuthenticationService(
//             IUserRepository userRepository,
//             IPasswordHasher<Admin> passwordHasher,
//             JwtTokenService jwtTokenService,
//             ILogger<AuthenticationService> logger)
//         {
//             _userRepository = userRepository;
//             _passwordHasher = passwordHasher;
//             _jwtTokenService = jwtTokenService;
//             _logger = logger;
//         }

//         // Register Admin
//         public async Task<Admin> RegisterAsync(AdminDTO model)
//         {
//             var existingAdmin = await _userRepository.GetAdminByEmailAsync(model.Email);
//             if (existingAdmin != null)
//             {
//                 _logger.LogWarning("Admin with email {Email} already exists.", model.Email);
//                 return null; // Admin already exists
//             }

//             var hashedPassword = _passwordHasher.HashPassword(null, model.Password);

//             var admin = new Admin
//             {
//                 Email = model.Email,
//                 Password = hashedPassword
//             };

//             await _userRepository.AddAsync(admin);
//             return admin;
//         }

//         // Authenticate Admin (Login)
//         public async Task<string> AuthenticateAsync(string email, string password)
//         {
//             if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
//             {
//                 _logger.LogError("Email or password is null or empty.");
//                 return null;
//             }

//             var admin = await _userRepository.GetAdminByEmailAsync(email);
//             if (admin == null)
//             {
//                 _logger.LogWarning("Admin with email {Email} not found.", email);
//                 return null;
//             }

//             var passwordMatch = _passwordHasher.VerifyHashedPassword(admin, admin.Password, password);
//             if (passwordMatch == PasswordVerificationResult.Failed)
//             {
//                 _logger.LogWarning("Password verification failed for email {Email}.", email);
//                 return null;
//             }

//             _logger.LogInformation("Admin {Email} authenticated successfully.", email);
//             return _jwtTokenService.GenerateJwtToken(admin.Email, "Admin", admin.AdminId, 30); // 30 minutes expiry
//         }
//     }
// }
