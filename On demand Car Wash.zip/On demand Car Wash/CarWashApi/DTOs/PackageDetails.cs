using System.ComponentModel.DataAnnotations;

namespace CarWashApi.DTOs
{
    public class PackageDetailDTO
    {
        public int PackageId { get; set; }

        [Required(ErrorMessage = "PackageName is required.")]
        [StringLength(100, ErrorMessage = "PackageName cannot be longer than 100 characters.")]
        public string PackageName { get; set; }

        [Range(0.01, double.MaxValue, ErrorMessage = "Price must be greater than 0.")]
        public decimal Price { get; set; }

        [Required(ErrorMessage = "IsActive is required.")]
        public bool IsActive { get; set; }
    }
}
